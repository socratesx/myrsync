package com.linminitools.mysync;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import static com.linminitools.mysync.MainActivity.configs;

import java.util.ArrayList;
import java.util.Map;


public class tab3 extends android.support.v4.app.Fragment {

    @Override
    public android.view.View onCreateView(android.view.LayoutInflater inflater, android.view.ViewGroup container,
            Bundle savedInstanceState) {
        android.view.ViewGroup rootView = (android.view.ViewGroup) inflater.inflate(
                R.layout.tab3, container, false);

        Context c = getContext();
        ListView lv_configs = (ListView) rootView.findViewById(R.id.lv_configs);
        lv_configs.setClickable(true);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(rootView.getContext(),android.R.layout.simple_list_item_1);

        SharedPreferences prefs = c.getSharedPreferences("configs",c.MODE_PRIVATE);

        for (RS_Configuration i : configs){
           adapter.add(i.id);
        }

        lv_configs.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //RS_Configuration config= configs.get(position);
                Intent i = new Intent(getContext(),editConfig.class);
                i.putExtra("pos",position);
                startActivity(i);


                /*
                i.putExtra("rs_user",config.rs_user);
                i.putExtra("rs_ip",config.rs_ip);
                i.putExtra("rs_port",config.rs_port);
                i.putExtra("rs_options",config.rs_options);
                i.putExtra("rs_module",config.rs_module);
                i.putExtra("id",config.id);
                i.putExtra("local_path",config.local_path);
                */
            }


        });
        lv_configs.setAdapter(adapter);

        return rootView;
    }



}

