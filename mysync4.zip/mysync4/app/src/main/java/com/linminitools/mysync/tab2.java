package com.linminitools.mysync;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;


public class tab2 extends android.support.v4.app.Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
            ViewGroup rootView = (android.view.ViewGroup) inflater.inflate(
                R.layout.tab2, container, false);

            Context c = getContext();
            SharedPreferences prefs = c.getSharedPreferences("Rsync_Command_build", c.MODE_PRIVATE);



            String local_path = prefs.getString("local_path","");
            String rs_user = prefs.getString("rs_user","");
            String rs_srv= prefs.getString("rs_srv","");
            String port = prefs.getString("port","873");
            String module = prefs.getString("rs_mod","");

            if (local_path!=""){
                TextView path= rootView.findViewById(R.id.tv_path);
                path.setText(local_path);
                path.setVisibility(View.VISIBLE);
            }

            if (rs_user!=""){
                EditText user= rootView.findViewById(R.id.ed_rsync_user);
                user.setHint(rs_user);
            }

            if (rs_srv!=""){
                EditText srv= rootView.findViewById(R.id.ed_srv_ip);
                srv.setHint(rs_srv);
            }

            if (port!=""){
                EditText ed_port= rootView.findViewById(R.id.ed_srv_port);
                ed_port.setHint(port);
            }
            if (module!=""){
                EditText ed_mod= rootView.findViewById(R.id.ed_rsync_mod);
                ed_mod.setHint(module);
            }

        return rootView;
    }





}

