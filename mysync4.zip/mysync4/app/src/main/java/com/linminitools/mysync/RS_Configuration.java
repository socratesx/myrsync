package com.linminitools.mysync;

import java.util.ArrayList;

public class RS_Configuration {

    public String rs_ip, rs_port, rs_user, rs_module, rs_options, local_path, id;


}
