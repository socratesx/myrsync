package com.linminitools.mysync;

import android.os.Bundle;

public class tab1 extends android.support.v4.app.Fragment {

    @Override
    public android.view.View onCreateView(android.view.LayoutInflater inflater, android.view.ViewGroup container,
            Bundle savedInstanceState) {
        android.view.ViewGroup rootView = (android.view.ViewGroup) inflater.inflate(
                R.layout.tab1, container, false);

        return rootView;
    }
}

