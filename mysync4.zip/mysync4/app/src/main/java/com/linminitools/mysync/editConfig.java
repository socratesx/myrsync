package com.linminitools.mysync;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import static com.linminitools.mysync.MainActivity.configs;

public class editConfig extends addConfig {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_config);
        Button save = findViewById(R.id.bt_save);
        Button view = findViewById(R.id.bt_view);
        save.setEnabled(true);
        view.setEnabled(true);

        Intent i =getIntent();
        int p=i.getIntExtra("pos",0);
        RS_Configuration config=configs.get(p);

        String rs_ip = config.rs_ip;
        String rs_user = config.rs_user;
        String rs_port = config.rs_port;
        String rs_options = config.rs_options;
        String rs_module= config.rs_module;
        String id = config.id ;
        String local_path = config.local_path;

        if(rs_options=="-"){rs_options="";}

        EditText ed_srv_ip = findViewById(R.id.ed_srv_ip);
        EditText ed_rsync_user = findViewById(R.id.ed_rsync_user);
        EditText ed_srv_port = findViewById(R.id.ed_srv_port);
        EditText ed_rsync_mod = findViewById(R.id.ed_rsync_mod);
        Button bt_add = findViewById(R.id.bt_add);
        TextView tv_path = findViewById(R.id.tv_path);


        ed_rsync_mod.setText(rs_module);
        ed_rsync_user.setText(rs_user);
        ed_srv_ip.setText(rs_ip);
        ed_srv_port.setText(rs_port);
        bt_add.setText("Change Path");
        tv_path.setVisibility(View.VISIBLE);
        tv_path.setText(local_path);

        if (!rs_options.isEmpty()) {
            String options = rs_options.substring(1);
            for (char x : options.toCharArray()) {
                String Rid = "R.id.cb_" + String.valueOf(x);
                //String Rid= "R.id.tv_path";
                Log.d("Rid=",Rid);
                int resID = this.getResources().getIdentifier(Rid, "id", "com.linminitools.mysync");
                Log.d("resID=",String.valueOf(resID));
                CheckBox cb = findViewById(resID);
                cb.setChecked(true);
            }
        }

        /*
        i.getStringExtra("rs_ip");
        i.getStringExtra("rs_port");
        i.getStringExtra("rs_options");
        i.getStringExtra("rs_module");
        i.getStringExtra("id");
        i.getStringExtra("local_path");
        */



    }


}
